-- Meditate on changing data with "UPDATE"
_____ book
set available = 1
where id = 2

-- Meditate on removing data with "DELETE"
_____ from customer
where id = 20001
