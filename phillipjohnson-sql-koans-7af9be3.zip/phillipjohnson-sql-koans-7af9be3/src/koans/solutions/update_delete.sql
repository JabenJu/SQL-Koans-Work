-- Meditate on changing data with "UPDATE"
update book
set available = 1
where id = 2

-- Meditate on removing data with "DELETE"
delete from customer
where id = 20001