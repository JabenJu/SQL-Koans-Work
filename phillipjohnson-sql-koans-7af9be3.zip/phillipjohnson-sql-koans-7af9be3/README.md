# SQL Koans
The SQL koans are a set of koans to introduce you to SQL. See [the website](http://sqlkoans.com) for more information. For the impatient...

## Climb the Mountain
```sh
$ git clone https://github.com/phillipjohnson/sql-koans
$ python sql-koans/src/path_to_enlightenment.py
```
